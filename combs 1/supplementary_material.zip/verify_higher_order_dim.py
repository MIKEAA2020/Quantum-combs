"""
Real-arithmetic version. The constraint maps preserve the splitting of
hermitian operators into real-symmetric and i*(real-antisymmetric) parts,
so everything is done in float64 over the reals in the two sectors.

cone dim = sum over sectors (sector dim - rank of its constraint map);
affine dimension = cone - 1.
"""
import numpy as np

def sector_basis(n):
    sym, anti = [], []
    for i in range(n):
        M = np.zeros((n, n)); M[i, i] = 1.0; sym.append(M)
    s = 1.0 / np.sqrt(2)
    for i in range(n):
        for j in range(i + 1, n):
            M = np.zeros((n, n)); M[i, j] = M[j, i] = s; sym.append(M)
            A = np.zeros((n, n)); A[i, j] = s; A[j, i] = -s; anti.append(A)  # represents op iA
    return sym, anti

def partial_trace_mat(R, dims, keep):
    cur = R.reshape(list(dims) + list(dims))
    cur_dims = list(dims)
    for s_ in sorted([i for i in range(len(dims)) if i not in keep], reverse=True):
        cur = np.trace(cur, axis1=s_, axis2=s_ + len(cur_dims))
        cur_dims.pop(s_)
    dk = int(np.prod([dims[i] for i in keep])) if keep else 1
    return cur.reshape(dk, dk)

def coords_in_sector(W, basis_list):
    return np.array([np.sum(S * W) for S in basis_list])  # Frobenius (basis orthonormal)

def sector_maps(dims, tol=1e-7, verbose=False):
    """Return kernel dimension of the full constraint map (both sectors combined)."""
    n = len(dims)
    full = int(np.prod(dims))
    results = 0
    for sector in ("sym", "anti"):
        cur_dims = list(dims)
        base_sym, base_anti = sector_basis(full)
        base = base_sym if sector == "sym" else base_anti
        coeff = np.eye(len(base))
        ranksum = 0
        m = n - 1
        while m >= 1:
            d_out, d_id = cur_dims[m], cur_dims[m - 1]
            keep_small = list(range(m - 1))
            dm1 = int(np.prod(cur_dims[:m]))
            cod_sym, cod_anti = sector_basis(dm1)
            cod = cod_sym if sector == "sym" else cod_anti
            G = np.zeros((len(cod), len(base)))
            for r, R in enumerate(base):
                Tr_m = partial_trace_mat(R, cur_dims, list(range(m)))
                Tr_mm1 = partial_trace_mat(R, cur_dims, keep_small)
                W = Tr_m - np.kron(Tr_mm1 / d_id, np.eye(d_id))
                G[:, r] = coords_in_sector(W, cod)
            GC = G @ coeff
            ranksum += np.linalg.matrix_rank(GC, tol=tol)
            # descend
            new_dims = cur_dims[:m - 1]
            nf = int(np.prod(new_dims)) if new_dims else 1
            nb_sym, nb_anti = sector_basis(nf)
            nbasis = nb_sym if sector == "sym" else nb_anti
            T = np.zeros((len(nbasis), len(base)))
            for r, R in enumerate(base):
                W = partial_trace_mat(R, cur_dims, keep_small)
                T[:, r] = coords_in_sector(W, nbasis)
            base, coeff, cur_dims = nbasis, T @ coeff, new_dims
            m -= 2
        results += len(base) if False else 0
        # sector contribution to kernel: sector original dim - ranksum
        orig_dim = n_ = full * full
        s0, a0 = sector_basis(full)
        dim_sector = len(s0) if sector == "sym" else len(a0)
        results += dim_sector - ranksum
        if verbose:
            print(f"  sector {sector}: dim={dim_sector}, ranksum={ranksum}")
    return results

def comb_dimension_formula(dims):
    if len(dims) == 2:
        return dims[0] ** 2 * (dims[1] ** 2 - 1)
    P_full = int(np.prod([d * d for d in dims]))
    P_drop = int(np.prod([d * d for d in dims[:-1]]))
    return (P_full - P_drop) + comb_dimension_formula(dims[:-2])

def comb_dimension_numeric(dims, **kw):
    return sector_maps(dims, **kw) - 1

if __name__ == "__main__":
    tests = [[2, 2], [2, 2, 2, 2], [2, 3, 2, 2],
             [2, 2, 2, 2, 2, 2], [3, 2, 2, 2, 2, 2]]
    allok = True
    for dims in tests:
        pred = comb_dimension_formula(dims)
        num = comb_dimension_numeric(dims)
        ok = num == pred
        allok &= ok
        print(f"{'OK ' if ok else 'MISMATCH'} dims={dims} formula={pred} numeric={num}")
    # display the true order-2 polynomial
    import sympy as sp
    c, x1, x2, x3, x4, dd = sp.symbols('c x1 x2 x3 x4 d')
    D = sp.expand(comb_dimension_formula([c, x1, x2, x3, x4, dd]))
    print("\norder-2 determinant-comb dimension polynomial (variables are UNSQUARED dims):")
    print(" D =", D)
    print(" factored:", sp.factor(D))
    print("\nALL OK" if allok else "\nFAILURES PRESENT")

def sector_pairs(n):
    sym_idx = [(i, i) for i in range(n)] + [(i, j) for i in range(n) for j in range(i + 1, n)]
    anti_idx = [(i, j) for i in range(n) for j in range(i + 1, n)]
    return sym_idx, anti_idx

def sector_element(n, idx, sector):
    s = 1.0 / np.sqrt(2)
    M = np.zeros((n, n))
    if sector == "sym":
        i, j = idx
        if i == j:
            M[i, i] = 1.0
        else:
            M[i, j] = M[j, i] = s
    else:
        i, j = idx
        M[i, j] = s; M[j, i] = -s
    return M

def sector_maps_lazy(dims, tol=1e-7, verbose=False):
    n = len(dims)
    full = int(np.prod(dims))
    total_kernel = 0
    for sector in ("sym", "anti"):
        cur_dims = list(dims)
        # level 0: iterate basis lazily
        idx_list = sector_pairs(full)[0 if sector == "sym" else 1]
        dim_sector = len(idx_list)
        coeff = None  # means identity
        ranksum = 0
        m = n - 1
        lazy = True
        base_list = None
        while m >= 1:
            d_out, d_id = cur_dims[m], cur_dims[m - 1]
            keep_small = list(range(m - 1))
            dm1 = int(np.prod(cur_dims[:m]))
            cod_sym, cod_anti = sector_basis(dm1)
            cod = cod_sym if sector == "sym" else cod_anti
            nb = dim_sector if lazy else len(base_list)
            G = np.zeros((len(cod), nb))
            for r in range(nb):
                R = sector_element(full, idx_list[r], sector) if lazy else base_list[r]
                Tr_m = partial_trace_mat(R, cur_dims, list(range(m)))
                Tr_mm1 = partial_trace_mat(R, cur_dims, keep_small)
                W = Tr_m - np.kron(Tr_mm1 / d_id, np.eye(d_id))
                G[:, r] = coords_in_sector(W, cod)
            GC = G if lazy else G @ coeff
            ranksum += np.linalg.matrix_rank(GC, tol=tol)
            # descend: build small basis as list
            new_dims = cur_dims[:m - 1]
            nf = int(np.prod(new_dims)) if new_dims else 1
            nb_sym, nb_anti = sector_basis(nf)
            nbasis = nb_sym if sector == "sym" else nb_anti
            T = np.zeros((len(nbasis), nb))
            for r in range(nb):
                R = sector_element(full, idx_list[r], sector) if lazy else base_list[r]
                W = partial_trace_mat(R, cur_dims, keep_small)
                T[:, r] = coords_in_sector(W, nbasis)
            coeff = T if lazy else T @ coeff
            base_list, cur_dims, lazy = nbasis, new_dims, False
            m -= 2
        total_kernel += dim_sector - ranksum
        if verbose:
            print(f"  sector {sector}: dim={dim_sector}, ranksum={ranksum}", flush=True)
    return total_kernel

def comb_dimension_numeric_lazy(dims, **kw):
    return sector_maps_lazy(dims, **kw) - 1
