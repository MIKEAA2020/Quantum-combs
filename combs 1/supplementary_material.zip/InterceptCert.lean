/-
Machine-certified arithmetic cores for
"Quantum Combs, Higher-Order Processes, and the Normalization-Defect (Intercept) Principle"
(Amin Abaee).

Scope: the two arithmetic statements that the article proves analytically and
that the supplementary package previously corroborated only numerically
(supplementary checks 3 and 5). Everything in this file is checked by the
Lean 4 kernel (core Lean only; no Mathlib).

Build:  lean InterceptCert.lean
Exit code 0 with no messages means every theorem below is kernel-verified.
-/

/-- Geometric sum `b^0 + b^1 + ... + b^(e-1)`, as a plain list sum so that
no external library is needed. -/
def geomSum (b e : Nat) : Nat := ((List.range e).map (fun i => b ^ i)).sum

/-- Strictly between consecutive squares implies not a square. -/
theorem not_square_of_between {n m : Nat}
    (hlo : m * m < n) (hhi : n < (m + 1) * (m + 1)) :
    ¬ ∃ k, k * k = n := by
  rintro ⟨k, rfl⟩
  rcases Nat.lt_or_ge k (m + 1) with h | h
  · have hge : k ≤ m := by omega
    have h1 : k * k ≤ m * m := Nat.mul_le_mul hge hge
    omega
  · have h3 : (m + 1) * (m + 1) ≤ k * k := Nat.mul_le_mul h h
    omega

/-- Expansion of (n+1)^2. -/
theorem sq_succ (n : Nat) : (n + 1) * (n + 1) = n * n + (2 * n + 1) := by
  calc (n + 1) * (n + 1) = (n + 1) * n + (n + 1) * 1 := Nat.mul_add _ _ _
    _ = (n + 1) * n + (n + 1) := by rw [Nat.mul_one]
    _ = n * n + 1 * n + (n + 1) := by rw [Nat.add_mul]
    _ = n * n + (2 * n + 1) := by rw [Nat.one_mul]; omega

/-- Left-adjoint obstruction arithmetic (Theorem "No left adjoint for
environment decoration" and the channel toy model of Section 5): writing
the environment square as e = (m+2)^2, the value e - sqrt(e) + 1, i.e.
(m+2)^2 - (m+2) + 1, lies strictly between the consecutive squares
(m+1)^2 and (m+2)^2. -/
theorem intercept_between_squares (m : Nat) :
    (m + 1) * (m + 1) < (m + 2) * (m + 2) - (m + 2) + 1 ∧
    (m + 2) * (m + 2) - (m + 2) + 1 < (m + 2) * (m + 2) := by
  have h1 : (m + 1) * (m + 1) = m * m + (2 * m + 1) := sq_succ m
  have h2 : (m + 2) * (m + 2) = m * m + (4 * m + 4) := by
    change ((m + 1) + 1) * ((m + 1) + 1) = m * m + (4 * m + 4)
    rw [sq_succ (m + 1), h1]
    omega
  rw [h1, h2]
  omega

/-- The certified form of the left-adjoint arithmetic for all e ≥ 2:
`e^2 - e + 1` is never a perfect square. In the article e = d_E^2 ≥ 4
since d_E > 1, so the hypothesis e ≥ 2 covers all cases. Supplements the
exhaustive/random numerical corroboration of supplementary check 3. -/
theorem intercept_not_square {e : Nat} (he : e ≥ 2) :
    ¬ ∃ k, k * k = e * e - e + 1 := by
  obtain ⟨m, rfl⟩ : ∃ m, e = m + 2 := ⟨e - 2, by omega⟩
  exact not_square_of_between (intercept_between_squares m).1
                              (intercept_between_squares m).2

/-- One-step recurrence for the geometric sum. -/
theorem geomSum_succ (b e : Nat) : geomSum b (e + 1) = geomSum b e + b ^ e := by
  simp [geomSum, List.range_succ]

/-- Base value. -/
theorem geomSum_two (b : Nat) : geomSum b 2 = 1 + b := by
  rw [show (2 : Nat) = 1 + 1 from rfl, geomSum_succ, geomSum_succ]
  simp [geomSum, Nat.pow_zero, Nat.pow_succ, Nat.one_mul]

/-- Powers of a number above 1 are at least 1. -/
theorem one_le_pow' {b : Nat} (hb : 1 ≤ b) : ∀ k : Nat, 1 ≤ b ^ k := by
  intro k; induction k with
  | zero => exact Nat.le_refl 1
  | succ k ih =>
      calc 1 = 1 * 1 := rfl
        _ ≤ b ^ k * b := Nat.mul_le_mul ih hb
        _ = b ^ (k + 1) := (Nat.pow_succ b k).symm

/-- Lower bound, parameterized form: for b ≥ 2 the geometric sum at k + 2
    strictly exceeds k + 2. -/
theorem geomSum_lb' {b : Nat} (hb : b ≥ 2) :
    ∀ k : Nat, (k + 2) + 1 ≤ geomSum b (k + 2) := by
  intro k; induction k with
  | zero => rw [geomSum_two]; omega
  | succ k ih =>
      rw [show k + 1 + 2 = k + 2 + 1 from rfl, geomSum_succ]
      have h1 : 1 ≤ b ^ (k + 2) := one_le_pow' (by omega) _
      omega

/-- Lower bound: for b ≥ 2 and e ≥ 2 the geometric sum strictly exceeds e. -/
theorem geomSum_lb {b : Nat} (hb : b ≥ 2) :
    ∀ {e : Nat}, e ≥ 2 → e + 1 ≤ geomSum b e := by
  intro e he
  obtain ⟨k, rfl⟩ : ∃ k, e = k + 2 := ⟨e - 2, by omega⟩
  exact geomSum_lb' hb k

/-- Exact geometric-sum identity: `(b - 1) * (1 + b + ... + b^(e-1)) = b^e - 1`. -/
theorem geomMul (b : Nat) (hb : b ≥ 2) : ∀ e : Nat, (b - 1) * geomSum b e = b ^ e - 1 := by
  intro e; induction e with
  | zero => simp [geomSum]
  | succ k ih =>
      rw [geomSum_succ, Nat.mul_add, ih]
      have h1 : 1 ≤ b ^ k := one_le_pow' (by omega) k
      have h2 : b ^ (k + 1) = b ^ k * b := Nat.pow_succ b k
      have h3 : (b - 1) * b ^ k = b ^ k * b - b ^ k := by
        rw [Nat.sub_mul, Nat.one_mul, Nat.mul_comm]
      have h4 : b ^ k ≤ b ^ k * b := by
        calc b ^ k = b ^ k * 1 := (Nat.mul_one _).symm
          _ ≤ b ^ k * b := Nat.mul_le_mul_left _ (by omega)
      omega

/-- FinStoch toy-model proposition (Section 5 of the article): the equation
`b^e - 1 = e * (b - 1)` has no solutions with b, e > 1. Kernel-certified
for all parameters, supplementing the exhaustive/random numerical sweep
of supplementary check 5. -/
theorem finstoch_no_solution {b e : Nat} (hb : b ≥ 2) (he : e ≥ 2) :
    b ^ e - 1 ≠ e * (b - 1) := by
  intro h
  have hs : e + 1 ≤ geomSum b e := geomSum_lb hb he
  have hm : (b - 1) * geomSum b e = b ^ e - 1 := geomMul b hb e
  have hcan : (b - 1) * e = (b - 1) * geomSum b e := by
    calc (b - 1) * e = e * (b - 1) := Nat.mul_comm _ _
      _ = b ^ e - 1 := h.symm
      _ = (b - 1) * geomSum b e := hm.symm
  have hsc : e = geomSum b e := Nat.mul_left_cancel (by omega) hcan
  omega

-- Axiom audit: every theorem must be free of sorryAx. Any output below that
-- lists only Lean's trusted kernel axioms (or none) is a pass.
#print axioms not_square_of_between
#print axioms sq_succ
#print axioms intercept_between_squares
#print axioms intercept_not_square
#print axioms geomSum_succ
#print axioms geomSum_two
#print axioms one_le_pow'
#print axioms geomSum_lb'
#print axioms geomSum_lb
#print axioms geomMul
#print axioms finstoch_no_solution
