"""
Symbolic verification of the two obstruction coefficient comparisons in
all_orders_universality.tex:

  Rigidity pair (Theorem 4.2 / Lemma 3.5):  coeff of x_1 = y_1, constant = -y_1.
  Top monomial  (Lemma 5.1):  coeff of y_1...y_{2l} = prod p_i   (LHS, type P)
                              = e^{2l} prod x_i                  (decorated RHS).

The wire word W(X,Y) is generated directly from Definition 2.2 and the
dimension polynomial from Theorem 3.1's pair form
  D = sum_t (prod_{i<2t} w_i)(w_{2t} - 1).
"""
import sympy as sp

def wire_word(k, l):
    W = []
    if k <= l:
        for j in range(1, k + 1):
            W += [('Y', 2*j-1), ('X', 2*j-1), ('X', 2*j), ('Y', 2*j)]
        W += [('Y', j) for j in range(2*k + 1, 2*l + 1)]
    else:
        for j in range(1, l):
            W += [('Y', 2*j-1), ('X', 2*j-1), ('X', 2*j), ('Y', 2*j)]
        W.append(('Y', 2*l-1))
        W += [('X', j) for j in range(2*l - 1, 2*k + 1)]
        W.append(('Y', 2*l))
    return W

def pair_form(k, l):
    W = wire_word(k, l)
    val = {('X', i): sp.Symbol(f"x{i}") for i in range(1, 2*k + 1)}
    for j in range(1, 2*l + 1):
        val[('Y', j)] = sp.Symbol(f"y{j}")
    D, Pprev = 0, 1
    for t, w in enumerate(W, start=1):
        if t % 2 == 0:
            D += Pprev * (val[w] - 1)
        Pprev *= val[w]
    return sp.expand(D)

e = sp.Symbol('e')
ok_right = ok_left = True
for k, l in [(1, 1), (1, 3), (2, 1), (2, 2), (3, 2), (4, 4)]:
    D = pair_form(k, l)
    x1, y1 = sp.Symbol('x1'), sp.Symbol('y1')
    c1 = sp.expand(D).coeff(x1, 1).subs({sp.Symbol(f'x{i}'): 0 for i in range(2, 2*k+1)})
    c0 = D.subs({sp.Symbol(f'x{i}'): 0 for i in range(1, 2*k+1)})
    good = sp.simplify(c1 - y1) == 0 and sp.simplify(c0 + y1) == 0
    ok_right &= good
    print(f"rigidity (k,l)=({k},{l}): coeff(x1)={sp.factor(c1)} const={sp.factor(c0)} [{'OK' if good else 'FAIL'}]")

for k, l in [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 3), (2, 4), (4, 2)]:
    D = pair_form(k, l)
    ymon = sp.prod(sp.Symbol(f"y{j}") for j in range(1, 2*l + 1))
    top = sp.expand(D).coeff(ymon, 1)
    xprod = sp.prod(sp.Symbol(f"x{i}") for i in range(1, 2*k + 1))
    ys = {sp.Symbol(f"y{j}"): e * sp.Symbol(f"y{j}") for j in range(1, 2*l + 1)}
    topdec = sp.expand(D.subs(ys)).coeff(ymon, 1)
    good = sp.simplify(top - xprod) == 0 and sp.simplify(topdec - e**(2*l) * xprod) == 0
    ok_left &= good
    print(f"top monomial (k,l)=({k},{l}): LHS={sp.factor(top)} decorated={sp.factor(topdec)} [{'OK' if good else 'FAIL'}]")

print("ALL OK, EXIT 0" if (ok_right and ok_left) else "FAILURES")
raise SystemExit(0 if (ok_right and ok_left) else 1)
